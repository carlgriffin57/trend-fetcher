# Trend Fetcher API

A simple Flask API that fetches Google Trends data in real time using PyTrends.

## 🚀 Endpoint
GET /trend?keyword=<your_keyword>

Example:
https://your-render-url.onrender.com/trend?keyword=AI+automation

Response:
{
  "keyword": "AI automation",
  "trend_direction": "rising",
  "growth_rate": 18.5,
  "search_volume_index": 82,
  "timestamp": "2025-11-14T00:00:00Z"
}

## ⚙️ Deployment on Render
1. Push this folder to a GitHub repo.
2. On Render, create a **New Web Service** and connect your repo.
3. Set **Start Command** to:
